# ንባብ Hub – Android project

Your `index.html` is bundled in `app/src/main/assets/index.html` and shown in a WebView.

## Option A – GitHub (no installation)
1. Create a new GitHub repository and upload everything in this folder
   (keep the `.github` folder).
2. Open the **Actions** tab -> "Build APK and AAB" (runs automatically on push).
3. When it finishes, download `nebab-hub-apk` (.apk) and `nebab-hub-aab` (.aab)
   from the run's **Artifacts**.

## Option B – Android Studio
1. Open this folder in Android Studio and let it sync.
2. Create a key: `keytool -genkeypair -keystore app/release.jks -alias nebab -keyalg RSA -keysize 2048 -validity 10000 -storepass nebab12345 -keypass nebab12345`
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s) or Build Bundle(s).
   Outputs: `app/build/outputs/apk/release/` and `app/build/outputs/bundle/release/`.

## Before publishing to Google Play
- Use your own permanent keystore and keep it safe (the one above is only for testing).
- Change `applicationId` (`com.nebabhub.app`) in `app/build.gradle` if you want your own package name.
- Replace the placeholder icon in `app/src/main/res`.
